<footer id="footerWrapper">
    <section id="mainFooter">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <div class="footerWidget">
                        <img src="../dashboard/assets/image/logo_name.png" alt="logo" id="footerLogo">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has
                            been the industry's standard dummy text ever since the 1500s, when an unknown printer took a
                            galley of type and scrambled it to make a type specimen book</p>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="footerWidget">
                        <h3>Links</h3>
                        <ul class="footerMenu">
                            <li><a>Home</a></li>
                            <li><a>Home</a></li>
                            <li><a>Home</a></li>
                        </ul>

                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="footerWidget">
                        <h3>Social Links</h3>
                        <ul class="socialNetwork">
                            <li><a href="#" title="follow me on Facebook"><i
                                        class="icon-facebook-1 iconRounded"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="footerRights">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <p>Copyright © 2016 Library / All rights reserved.</p>
                </div>

            </div>
        </div>
    </section>
</footer>