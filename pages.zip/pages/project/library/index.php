<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Library: Home</title>
    <!--<META HTTP-EQUIV="Refresh" CONTENT="0;URL=http://library.freeoda.com/app/view/index.php">-->
    <META HTTP-EQUIV="Refresh" CONTENT="0;URL=http://localhost/library/app/view/index.php">
</head>
<body>

</body>
</html>
